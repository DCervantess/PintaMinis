import * as FileSystem from 'expo-file-system/legacy';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type GenerateOptions = { style: string; level: string; brand: string };
const URL_KEY = 'pinta-miniaturas-api-url';
const ENV_URL = process.env.EXPO_PUBLIC_API_URL?.replace(/\/$/, '');
let cachedUrl: string | null = ENV_URL || null;

export async function getApiUrl() {
  if (cachedUrl) return cachedUrl;
  cachedUrl = (await AsyncStorage.getItem(URL_KEY))?.replace(/\/$/, '') || null;
  return cachedUrl;
}

export async function setApiUrl(url: string) {
  const clean = url.trim().replace(/\/+$/, '');
  if (clean) await AsyncStorage.setItem(URL_KEY, clean);
  else await AsyncStorage.removeItem(URL_KEY);
  cachedUrl = clean || null;
  return cachedUrl;
}

export async function checkApiHealth() {
  const url = await getApiUrl();
  if (!url) throw new Error('Primero introduce la dirección del servidor.');
  const response = await fetch(`${url}/api/health`, { method: 'GET', signal: AbortSignal.timeout(12000) });
  const body = await response.json().catch(() => ({}));
  if (!response.ok || !body.ok) throw new Error(body.error || `El servidor respondió con el error ${response.status}.`);
  return body as { ok: boolean; app?: string; provider?: string };
}

export async function generatePreview(imageUri: string, options: GenerateOptions) {
  const API_URL = await getApiUrl();
  if (!API_URL) throw new Error('Abre “Conexión” y configura la dirección del servidor de IA.');
  const base64 = await FileSystem.readAsStringAsync(imageUri, { encoding: FileSystem.EncodingType.Base64 });
  const ext = imageUri.split('?')[0].toLowerCase();
  const mimeType = ext.endsWith('.png') ? 'image/png' : ext.endsWith('.webp') ? 'image/webp' : 'image/jpeg';
  const response = await fetch(`${API_URL}/api/generate-preview`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ imageBase64: base64, mimeType, ...options }),
    signal: AbortSignal.timeout(150000)
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `El servidor respondió con el error ${response.status}.`);
  if (!body.imageUrl && !body.imageBase64) throw new Error('El servidor no devolvió una imagen válida.');
  return body as { imageUrl?: string; imageBase64?: string; mimeType?: string; guidance?: string[]; palette?: { name: string; hex: string; paint?: string }[]; notice?: string };
}
