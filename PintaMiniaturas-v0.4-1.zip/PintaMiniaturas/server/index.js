import 'dotenv/config';
import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors({
  origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',').map(x => x.trim()) : true,
  methods: ['GET', 'POST'],
}));
app.use(express.json({ limit: '12mb' }));

const MAX_IMAGE_BASE64_CHARS = 10 * 1024 * 1024;
const ALLOWED_MIME = new Set(['image/jpeg', 'image/png', 'image/webp']);

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    app: 'pinta-miniaturas-api',
    provider: process.env.AI_PROVIDER === 'stability' && process.env.STABILITY_API_KEY
      ? 'stability-configured'
      : process.env.AI_PROVIDER_URL ? 'custom-adapter-configured' : 'not-configured'
  });
});

function makePrompt({ style, level, brand }) {
  const styleText = {
    'Fantasía oscura': 'dark fantasy tabletop miniature, restrained desaturated colors, dramatic but readable miniature lighting',
    'Alta fantasía': 'high fantasy tabletop miniature, rich jewel tones and carefully balanced magical accents',
    'Realista': 'realistic historical materials, believable leather, metal, cloth and skin colors',
    'Eavy metal': 'competition display miniature, crisp edge highlights, strong contrast and clean color separation',
    'Colores vivos': 'vibrant tabletop miniature color scheme, saturated but harmonious colors'
  }[style] || style;

  return [
    'Edit the provided photo into a realistic painted tabletop miniature preview.',
    'CRITICAL: preserve the exact miniature identity, silhouette, pose, proportions, sculpted details, equipment, base, camera angle and framing.',
    'Do not add or remove limbs, weapons, armor pieces, ornaments, scenery or characters. Do not redesign the sculpt.',
    'Only change paint colors, material finish, shadows and highlights on existing surfaces.',
    `Requested visual treatment: ${styleText}.`,
    `Painter skill level: ${level}. Use a scheme achievable at this level.`,
    `Preferred paint brand for the later written guide: ${brand}.`,
    'Show a single miniature, sharp focus, neutral uncluttered background, realistic brush-painted acrylic miniature finish.',
    'Avoid painterly illustration, extra props, text, labels, watermarks, duplicate miniatures or altered anatomy.'
  ].join(' ');
}

function makeGuidance({ style, level, brand }) {
  const skill = level === 'Principiante'
    ? 'Prioriza capas base limpias y pocas mezclas; no necesitas transiciones complejas.'
    : level === 'Avanzado'
      ? 'Puedes añadir transiciones, luces selectivas y reflejos controlados donde la escultura lo permita.'
      : 'Trabaja con capas base, sombras selectivas y luces progresivas.';
  return [
    `Imprimación: usa una imprimación adecuada al material y deja secar por completo. ${style === 'Fantasía oscura' ? 'Una imprimación negra o gris oscuro facilitará mantener las sombras.' : 'Una imprimación gris neutra ayuda a valorar los colores.'}`,
    `Capas base: aplica capas finas en cada material y evita cubrir los detalles. ${skill}`,
    `Sombras: aplica lavados o sombras diluidas en recovecos, uniones y pliegues; retira acumulaciones de las superficies planas.`,
    `Luces: recupera las zonas expuestas con un tono más claro y termina con luces de borde en los puntos focales.`,
    `Detalles y acabado: pinta ojos, emblemas y pequeños metales al final; protege la miniatura con barniz compatible cuando esté seca.`,
    `Guía de colores orientativa para pinturas ${brand}: la vista previa es una referencia visual, no una identificación automática exacta de botes o códigos.`
  ];
}

function makePalette(style) {
  const palettes = {
    'Fantasía oscura': [
      { name: 'Sombra profunda', hex: '#252A31', paint: 'Base oscura orientativa' },
      { name: 'Cuero / bronce', hex: '#8A6044', paint: 'Marrón medio orientativo' },
      { name: 'Metal envejecido', hex: '#777D7B', paint: 'Metal oscuro orientativo' },
      { name: 'Luz cálida', hex: '#C7AD7A', paint: 'Marfil / ocre claro orientativo' },
      { name: 'Acento', hex: '#873D42', paint: 'Rojo oscuro orientativo' }
    ],
    'Alta fantasía': [
      { name: 'Azul real', hex: '#315B9B', paint: 'Azul medio orientativo' },
      { name: 'Dorado', hex: '#C39A45', paint: 'Oro orientativo' },
      { name: 'Hueso', hex: '#D8D0B8', paint: 'Hueso claro orientativo' },
      { name: 'Sombra', hex: '#34374A', paint: 'Azul oscuro orientativo' },
      { name: 'Acento mágico', hex: '#65B7A5', paint: 'Turquesa orientativo' }
    ],
    'Realista': [
      { name: 'Tela / cuero', hex: '#79614A', paint: 'Marrón tierra orientativo' },
      { name: 'Metal', hex: '#777D82', paint: 'Gris metálico orientativo' },
      { name: 'Sombra', hex: '#393B39', paint: 'Gris oscuro orientativo' },
      { name: 'Luz', hex: '#C6B99A', paint: 'Arena clara orientativa' },
      { name: 'Acento', hex: '#6B493F', paint: 'Marrón rojizo orientativo' }
    ],
    'Eavy metal': [
      { name: 'Color base', hex: '#315D8E', paint: 'Azul medio orientativo' },
      { name: 'Sombra', hex: '#202B43', paint: 'Azul oscuro orientativo' },
      { name: 'Luz de borde', hex: '#A9D4E8', paint: 'Azul hielo orientativo' },
      { name: 'Metal', hex: '#A5A9AA', paint: 'Plata orientativa' },
      { name: 'Acento', hex: '#D7B35A', paint: 'Oro claro orientativo' }
    ],
    'Colores vivos': [
      { name: 'Color principal', hex: '#D94D48', paint: 'Rojo vivo orientativo' },
      { name: 'Contraste', hex: '#286C9A', paint: 'Azul saturado orientativo' },
      { name: 'Luz', hex: '#F0D99A', paint: 'Marfil cálido orientativo' },
      { name: 'Sombra', hex: '#4A334D', paint: 'Violeta oscuro orientativo' },
      { name: 'Acento', hex: '#E2B94C', paint: 'Amarillo dorado orientativo' }
    ]
  };
  return palettes[style] || palettes['Fantasía oscura'];
}

async function generateWithStability({ imageBase64, mimeType, prompt }) {
  if (!process.env.STABILITY_API_KEY) {
    const err = new Error('Falta STABILITY_API_KEY en el archivo .env del servidor.');
    err.status = 503;
    throw err;
  }
  const engine = process.env.STABILITY_ENGINE || 'stable-diffusion-xl-1024-v1-0';
  const endpoint = `https://api.stability.ai/v1/generation/${encodeURIComponent(engine)}/image-to-image`;
  const bytes = Buffer.from(imageBase64, 'base64');
  const form = new FormData();
  form.append('init_image', new Blob([bytes], { type: mimeType }), `miniatura.${mimeType === 'image/png' ? 'png' : mimeType === 'image/webp' ? 'webp' : 'jpg'}`);
  form.append('text_prompts[0][text]', prompt);
  form.append('text_prompts[0][weight]', '1');
  form.append('text_prompts[1][text]', 'different miniature, altered pose, changed anatomy, extra limbs, extra weapons, extra characters, text, watermark, illustration, blurry details');
  form.append('text_prompts[1][weight]', '-1');
  form.append('image_strength', process.env.STABILITY_IMAGE_STRENGTH || '0.55');
  form.append('cfg_scale', '7');
  form.append('steps', process.env.STABILITY_STEPS || '30');
  form.append('samples', '1');

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.STABILITY_API_KEY}`,
      Accept: 'application/json'
    },
    body: form,
    signal: AbortSignal.timeout(120000)
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 500);
    const err = new Error(`Stability AI respondió ${response.status}. ${detail}`);
    err.status = 502;
    throw err;
  }
  const data = await response.json();
  const output = data?.artifacts?.find(x => x.finishReason === 'SUCCESS' && x.base64);
  if (!output?.base64) {
    const err = new Error('El proveedor no devolvió una imagen utilizable. Puede haber aplicado un filtro o cambiado el formato de respuesta.');
    err.status = 502;
    throw err;
  }
  return { imageBase64: output.base64, mimeType: 'image/png' };
}

async function generateWithCustomAdapter({ imageBase64, mimeType, prompt, style, level, brand }) {
  if (!process.env.AI_PROVIDER_URL) {
    const err = new Error('No hay proveedor de IA configurado. Configura Stability AI o un adaptador compatible en el servidor.');
    err.status = 503;
    throw err;
  }
  const upstream = await fetch(process.env.AI_PROVIDER_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(process.env.AI_PROVIDER_TOKEN ? { Authorization: `Bearer ${process.env.AI_PROVIDER_TOKEN}` } : {})
    },
    body: JSON.stringify({ imageBase64, mimeType, prompt, options: { style, level, brand } }),
    signal: AbortSignal.timeout(120000)
  });
  const payload = await upstream.json().catch(() => ({}));
  if (!upstream.ok) {
    const err = new Error(`El adaptador de IA respondió con el error ${upstream.status}.`);
    err.status = 502;
    throw err;
  }
  const imageUrl = payload.imageUrl ?? payload.output?.imageUrl ?? payload.data?.imageUrl;
  const outputBase64 = payload.imageBase64 ?? payload.output?.imageBase64 ?? payload.data?.imageBase64;
  if (!imageUrl && !outputBase64) {
    const err = new Error('El adaptador no devolvió imageUrl o imageBase64.');
    err.status = 502;
    throw err;
  }
  return {
    imageUrl,
    imageBase64: outputBase64,
    mimeType: payload.mimeType ?? payload.output?.mimeType ?? 'image/png',
    guidance: payload.guidance,
    palette: payload.palette
  };
}

app.post('/api/generate-preview', async (req, res) => {
  const { imageBase64, mimeType = 'image/jpeg', style, level, brand } = req.body ?? {};
  if (typeof imageBase64 !== 'string' || imageBase64.length < 100 || imageBase64.length > MAX_IMAGE_BASE64_CHARS) {
    return res.status(400).json({ error: 'La imagen falta, está vacía o supera el límite de tamaño (aprox. 7,5 MB).' });
  }
  if (!ALLOWED_MIME.has(mimeType)) {
    return res.status(400).json({ error: 'Formato no admitido. Usa JPEG, PNG o WebP.' });
  }
  if (!['Fantasía oscura', 'Alta fantasía', 'Realista', 'Eavy metal', 'Colores vivos'].includes(style)) {
    return res.status(400).json({ error: 'Selecciona un estilo válido.' });
  }
  if (!['Principiante', 'Intermedio', 'Avanzado'].includes(level) || !['Vallejo', 'Citadel', 'The Army Painter', 'AK Interactive', 'Otras'].includes(brand)) {
    return res.status(400).json({ error: 'Nivel o marca de pintura no válidos.' });
  }

  try {
    const prompt = makePrompt({ style, level, brand });
    let result;
    if (process.env.AI_PROVIDER === 'stability') {
      result = await generateWithStability({ imageBase64, mimeType, prompt });
    } else {
      result = await generateWithCustomAdapter({ imageBase64, mimeType, prompt, style, level, brand });
    }
    res.json({
      ...result,
      guidance: result.guidance || makeGuidance({ style, level, brand }),
      palette: result.palette || makePalette(style),
      notice: 'La imagen es una propuesta visual de IA. Los colores y equivalencias de pintura son orientativos, no una identificación exacta de botes.'
    });
  } catch (error) {
    console.error('Preview generation failed:', error?.message ?? error);
    res.status(error?.status || 502).json({ error: error?.message || 'No se pudo generar la vista previa.' });
  }
});

const port = Number(process.env.PORT || 8787);
app.listen(port, '0.0.0.0', () => console.log(`Pinta Miniaturas API escuchando en el puerto ${port}`));
