# Notas de análisis estático de SmartHobby

Fecha de revisión: 26-10-2026. Fuente: APK que aportó el usuario. Este documento recoge metadatos y nombres visibles encontrados en el paquete; no demuestra que cada pantalla o servicio funcione en el momento de la revisión.

## Metadatos observados
- Nombre de la app: SmartHobby.
- Paquete Android: `com.smarthobby.app`.
- Versión declarada en el manifiesto Expo: `1.0.0`.
- App basada en Expo/React Native.
- El paquete contiene un bundle JavaScript y referencias a servicios de terceros como Supabase, RevenueCat y Sentry. Esto sugiere que la app incluye componentes de autenticación/datos, suscripciones y telemetría; no revela las reglas privadas ni permite reproducir sus servidores.

## Rutas/pantallas cuyos nombres aparecen en el bundle
- Escaneo: `/escanear/estilo`, `/escanear/extras`, `/escanear/guia`, `/escanear/resultado`.
- Proyecto: `/proyecto`, `/proyecto/color-wheel`, `/proyecto/tecnicas`.
- Perfil y ajustes: `/perfil`, `/perfil/pinturas`, `/perfil/ajustes`, `/perfil/apariencia`, `/perfil/idioma`, `/perfil/suscripcion`, `/perfil/finalizados`, `/perfil/insignias`, `/perfil/amigos`, `/perfil/feed`, `/perfil/privacidad`, `/perfil/soporte`, `/perfil/terminos`, `/perfil/eliminar-cuenta`.
- Incorporación/registro: `/onboarding/registro`, `/onboarding/recuperar`, `/onboarding/personaliza`, `/onboarding/tutorial`.

Los nombres se han extraído de cadenas del bundle; no son una inspección visual completa de cada pantalla ni confirman que todas estén habilitadas para la cuenta del usuario.

## Implicaciones para nuestra app
1. El flujo de escaneo debería separar selección de estilo, opciones adicionales, generación y resultado.
2. Conviene modelar cada miniatura como un proyecto que pueda guardarse y volver a editarse.
3. La biblioteca de pinturas debe distinguir marca, gama, nombre comercial y código, y dejar claro cuándo una equivalencia es aproximada.
4. Suscripciones y autenticación pueden añadirse más adelante, pero no son necesarias para validar primero el flujo de foto → vista previa → guía.
5. No se intentará copiar el backend, las cuentas, las compras integradas ni los datos privados de SmartHobby. Esta aplicación tendrá su propio código, API y políticas.
