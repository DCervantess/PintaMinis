# Pinta Miniaturas — versión 0.4.0

Aplicación Android independiente para planificar la pintura de miniaturas de fantasía y wargames. No copia código privado, cuentas, compras ni servidores de SmartHobby.

## Cambios de esta versión
- Pantalla de conexión dentro de la app: puedes pegar la URL del servidor desde el propio móvil.
- Guarda la URL localmente en el dispositivo.
- Botón para comprobar `/api/health` y ver si el servidor tiene un proveedor configurado.
- El móvil ya no necesita que se compile una URL fija en `EXPO_PUBLIC_API_URL`.
- Continúa la integración de generación de imagen y guía de pintura del backend.

## Estado real
Esta versión es código fuente de desarrollo, no una APK instalable. La generación real todavía requiere desplegar el servidor y configurar una clave válida del proveedor. No se incluye ninguna clave ni se ha verificado aún una generación real. La calidad para conservar todos los detalles no está garantizada; la paleta es orientativa, no un catálogo de referencias exactas.

## Trabajar desde el móvil
Como estás haciendo el proyecto desde un teléfono, el flujo recomendado es:
1. Descarga el ZIP y guárdalo en el teléfono.
2. Para ejecutar y editar el proyecto sin PC, necesitarás un entorno de desarrollo en la nube que admita proyectos Node/Expo, o un ordenador más adelante. Un ZIP por sí solo no se ejecuta directamente como una app.
3. Despliega la carpeta `server` en un servicio Node.js que admita variables de entorno y HTTPS.
4. En la app, abre **Conexión con IA**, pega la URL HTTPS pública del backend y pulsa **Probar conexión**.
5. Cuando el servidor responda y el proveedor esté configurado, elige una foto y prueba **Generar vista previa con IA**.

No introduzcas una clave de Stability AI en la app ni en un chat. La clave va únicamente en las variables privadas del servidor.

## Servidor (para quien despliegue el proyecto)
Requiere Node.js 20+:
```bash
cd server
npm install
cp .env.example .env
```
Añade la clave en `STABILITY_API_KEY` y ejecuta:
```bash
npm start
```
El endpoint de salud es `GET /api/health`. El backend de ejemplo no está endurecido para producción: antes de publicarlo hay que añadir autenticación, límites de uso, límites de tamaño y controles antiabuso.

La integración usa el endpoint image-to-image de la API v1 de Stability AI. Revisa la documentación, disponibilidad de modelos y precios actuales:
- https://prod-alb.stability.ai/docs
- https://docs.stability.ai/pricing

Los créditos gratuitos y precios pueden cambiar; comprueba las condiciones actuales antes de generar imágenes.

## Crear la app
Desde un entorno con Node.js:
```bash
npm install
npx expo start
```
Para crear una APK instalable se debe configurar un build Android, por ejemplo con EAS Build. Esto aún no está realizado ni probado en un dispositivo.

## Próximos hitos
1. Desplegar el backend y comprobar una generación real.
2. Redimensionar/comprimir fotos en el móvil antes de subirlas.
3. Añadir autenticación y límites de uso para proteger el backend.
4. Guardar proyectos localmente.
5. Añadir catálogo de pinturas y equivalencias verificadas.
6. Crear y probar una APK en el Samsung Galaxy S24 Ultra.

## Privacidad
Al generar, la foto se envía al servidor que configures y, desde ahí, al proveedor de IA. Revisa sus condiciones de privacidad y retención. No publiques archivos `.env` ni claves.
